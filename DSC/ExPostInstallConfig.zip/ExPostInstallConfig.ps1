﻿Configuration ExPostInstallConfig {
    param
    (
        [Int]$RetryCount = 20,
        [Int]$RetryIntervalSec = 30
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xPendingReboot

    Node Localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }

        xWaitforDisk Disk2
        {
            DiskId = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        xDisk ExDataDisk {
            DiskId  = 2
            DriveLetter = "F"
            DependsOn   = "[xWaitForDisk]Disk2"
            FSLabel = 'Data'
        }
    }

}